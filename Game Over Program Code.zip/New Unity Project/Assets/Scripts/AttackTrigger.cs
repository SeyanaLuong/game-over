﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttackTrigger : MonoBehaviour {

    public int dmg = 1;

    void OnTriggerEnter2D(Collider2D collision)
    {
     if(collision.isTrigger !=  true && collision.CompareTag("Box"))
        {
            collision.SendMessageUpwards("DamageWall", dmg);
        }
     else if (collision.isTrigger != true && collision.CompareTag("Enemy"))
        {
            collision.SendMessageUpwards("DamageEnemy", dmg);
        }
    }
    
}
