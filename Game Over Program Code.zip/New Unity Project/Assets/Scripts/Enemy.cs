﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Enemy : MovingObject {

    public int playerDamage;
    public Sprite dmgSprite;
    public int hp;
    public AudioClip enemyAttack1;
    public AudioClip enemyAttack2;
    public AudioClip chopSound1;
    public AudioClip chopSound2;
    public AudioClip enemyMove1;
    public AudioClip enemyMove2;
    public AudioClip enemyDeath;


    private Animator animator;
    private Transform target;
    private bool skipMove;


    // Use this for initialization
    protected override void Start () {
        GameManager.instance.AddEnemyToList(this);
        animator = GetComponent<Animator>();
        target = GameObject.FindGameObjectWithTag("Player").transform;

        base.Start();
	}
	
	// Update is called once per frame
	void Update () {
        
    }

    public void DamageEnemy(int loss)
    {
        SoundManager.instance.RandomizeSfx(chopSound1, chopSound2);
        animator.SetTrigger("enemyHit");
        hp -= loss;
        if (hp <= 0)
        {
            gameObject.SetActive(false);
            SoundManager.instance.PlaySingle(enemyDeath);
        }
            
    }

    protected override void AttemptMove<T>(int xDir, int yDir)
    {
        if (skipMove)
        {
            skipMove = false;
            return;
        }
        base.AttemptMove<T>(xDir, yDir);
        skipMove = true;
    }

    public void MoveEnemy()
    {
        int xDir = 0;
        int yDir = 0;

        if (Mathf.Abs(target.position.x - transform.position.x) < float.Epsilon)
            yDir = target.position.y > transform.position.y ? 1 : -1;
        else
            xDir = target.position.x > transform.position.x ? 1 : -1;

        if (xDir == 1)
        {
            transform.localScale = new Vector3(-1f, 1f, 1f);
        }
        else if (xDir == -1)
        {
            transform.localScale = new Vector3(1f, 1f, 1f);
        }
        SoundManager.instance.RandomizeSfx(enemyMove1, enemyMove2);
        AttemptMove<Player>(xDir, yDir);
    }

    protected override void OnCantMove<T>(T component)
    {
        if (gameObject.activeSelf)
        {
            Player hitPlayer = component as Player;

            hitPlayer.LoseFood(playerDamage);

            animator.SetTrigger("enemyAttack");

            SoundManager.instance.RandomizeSfx(enemyAttack1, enemyAttack2);
       
            
        }  

    }

}
